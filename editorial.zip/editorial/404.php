<?php
get_header(); ?>

<!-- Post -->                 
<section class="post"> 
    <header class="major"> 
        <h1><?php _e( '404 Error', 'editorial' ); ?></h1>
        <p><?php _e( 'Something Went Wrong, Please Try Again', 'editorial' ); ?></p> 
    </header>                     
</section>                                 

<?php get_footer(); ?>